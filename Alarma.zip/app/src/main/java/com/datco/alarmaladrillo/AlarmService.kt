package com.datco.alarmaladrillo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "com.datco.alarmaladrillo.ALARM_STOP"
        const val ACTION_SNOOZE = "com.datco.alarmaladrillo.ALARM_SNOOZE"
        const val ACTION_STOPPED = "com.datco.alarmaladrillo.ALARM_STOPPED"
        const val CHANNEL = "alarma_suena"
        const val NOTIF_ID = 4021

        @Volatile
        var ringing = false

        @Volatile
        var currentType = "alarm"

        @Volatile
        var currentLabel = ""

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(ACTION_STOP))
        }

        fun snooze(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(ACTION_SNOOZE))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: SoundPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wake: PowerManager.WakeLock? = null
    private var vibrator: Vibrator? = null
    private var type = "alarm"
    private var sound = 0
    private var label = ""

    @Volatile
    private var message = ""

    private val speakLoop = object : Runnable {
        override fun run() {
            if (!ringing) return
            if (ttsReady) {
                tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "alarma")
            }
            handler.postDelayed(this, 70_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopRinging(true)
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                if (ringing) Scheduler.snooze(this, 10, sound, label)
                stopRinging(false)
                return START_NOT_STICKY
            }
        }
        if (ringing) return START_NOT_STICKY

        val t = intent?.getStringExtra(Scheduler.EXTRA_TYPE) ?: "alarm"
        type = if (t == "timer") "timer" else "alarm"
        sound = intent?.getIntExtra(Scheduler.EXTRA_SOUND, 0) ?: 0
        label = intent?.getStringExtra(Scheduler.EXTRA_LABEL) ?: ""
        currentType = type
        currentLabel = label
        ringing = true

        crearCanal()
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notificacion(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            // se intenta sonar igual
        }
        try {
            startActivity(
                Intent(this, AlarmActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (e: Exception) {
            // la notificación a pantalla completa se encarga
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarmaladrillo:alarma")
            wake?.acquire(11 * 60 * 1000L)
        } catch (e: Exception) {
        }

        player = SoundPlayer().also { it.start(sound, true) }

        try {
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 1400), 0))
        } catch (e: Exception) {
        }

        message = mensajeVoz(Weather.cached(this), type)
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                if (engine != null) {
                    var r = engine.setLanguage(Locale("es", "AR"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        r = engine.setLanguage(Locale("es"))
                    }
                    engine.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    ttsReady = true
                }
            }
        }
        // El clima se actualiza en segundo plano para que la voz diga lo más reciente
        if (type == "alarm") {
            Thread {
                val w = Weather.fetch(applicationContext)
                handler.post { message = mensajeVoz(w, type) }
            }.start()
        }
        handler.postDelayed(speakLoop, 10_000L)
        // si nadie la detiene, se apaga sola a los 10 minutos
        handler.postDelayed({ stopRinging(type == "alarm") }, 10 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun crearCanal() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Alarma sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        nm.createNotificationChannel(ch)
    }

    private fun notificacion(): Notification {
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val titulo = if (type == "timer") "Temporizador" else if (label.isNotEmpty()) label else "Alarma"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(titulo)
            .setContentText("Toca para abrir")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .build()
    }

    private fun stopRinging(endSleep: Boolean) {
        if (!ringing) {
            stopSelf()
            return
        }
        ringing = false
        handler.removeCallbacksAndMessages(null)
        player?.stop()
        player = null
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
        }
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (e: Exception) {
        }
        if (type == "alarm" && endSleep) SleepService.end(this)
        if (type == "timer") TimerStore.clear(this)
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        ringing = false
        player?.stop()
        super.onDestroy()
    }
}
