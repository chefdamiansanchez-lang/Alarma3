package com.datco.alarmaladrillo

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper

/** Sonidos suaves generados por código (no hace falta ningún archivo de audio). */
object SoundSynth {
    const val RATE = 22050
    val NAMES = listOf("Amanecer", "Pájaros", "Lluvia suave", "Olas", "Caja de música")

    fun generate(index: Int): ShortArray {
        val f = when (index) {
            0 -> amanecer()
            1 -> pajaros()
            2 -> lluvia()
            3 -> olas()
            else -> cajaMusica()
        }
        var peak = 0f
        for (v in f) peak = maxOf(peak, Math.abs(v))
        val g = if (peak > 0f) 0.85f / peak else 1f
        return ShortArray(f.size) { (f[it] * g * 32767f).toInt().toShort() }
    }

    private fun addNote(buf: FloatArray, startSec: Double, freq: Double, durSec: Double, amp: Float, decay: Double) {
        val s0 = (startSec * RATE).toInt()
        val n = (durSec * RATE).toInt()
        for (i in 0 until n) {
            val idx = (s0 + i) % buf.size
            val t = i.toDouble() / RATE
            val attack = minOf(1.0, t / 0.01)
            val env = attack * Math.exp(-decay * t)
            val w = 2.0 * Math.PI * freq * t
            val v = (Math.sin(w) + 0.35 * Math.sin(2 * w) + 0.12 * Math.sin(3 * w)) * env * amp
            buf[idx] += v.toFloat()
        }
    }

    private fun amanecer(): FloatArray {
        val buf = FloatArray(RATE * 12)
        val notas = doubleArrayOf(523.25, 659.25, 783.99, 1046.5, 783.99, 659.25, 880.0, 783.99, 659.25, 587.33, 523.25, 392.0)
        for (i in notas.indices) addNote(buf, i * 1.0, notas[i], 2.6, 0.5f, 1.5)
        return buf
    }

    private fun cajaMusica(): FloatArray {
        val buf = FloatArray(RATE * 9)
        val esc = doubleArrayOf(1046.5, 1174.66, 1318.51, 1567.98, 1760.0, 2093.0)
        val mel = intArrayOf(0, 2, 3, 5, 3, 2, 1, 2, 3, 4, 3, 2, 0, 1, 2, 0)
        for (i in mel.indices) addNote(buf, i * 0.55, esc[mel[i]], 1.8, 0.5f, 3.2)
        return buf
    }

    private fun chirp(buf: FloatArray, startSec: Double, dur: Double, fa: Double, fb: Double, amp: Float) {
        val s0 = (startSec * RATE).toInt()
        val n = (dur * RATE).toInt()
        var phase = 0.0
        for (i in 0 until n) {
            val p = i.toDouble() / n
            val f = fa + (fb - fa) * p
            phase += 2.0 * Math.PI * f / RATE
            val env = Math.sin(Math.PI * p)
            val idx = s0 + i
            if (idx < buf.size) buf[idx] += (Math.sin(phase) * env * amp).toFloat()
        }
    }

    private fun pajaros(): FloatArray {
        val buf = FloatArray(RATE * 10)
        val r = java.util.Random(7)
        var t = 0.3
        while (t < 9.0) {
            val silabas = 2 + r.nextInt(3)
            var st = t
            val f0 = 2200.0 + r.nextInt(1400)
            val sube = r.nextBoolean()
            for (k in 0 until silabas) {
                val dur = 0.06 + r.nextDouble() * 0.05
                val fa = if (sube) f0 else f0 * 1.5
                val fb = if (sube) f0 * 1.5 else f0
                chirp(buf, st, dur, fa, fb, 0.22f)
                st += dur + 0.05
            }
            t = st + 0.4 + r.nextDouble() * 0.9
        }
        return buf
    }

    private fun lluvia(): FloatArray {
        val buf = FloatArray(RATE * 6)
        val r = java.util.Random(3)
        var lp = 0f
        for (i in buf.indices) {
            val n = r.nextFloat() * 2f - 1f
            lp += 0.25f * (n - lp)
            buf[i] = lp * 0.5f
        }
        for (k in 0 until 60) {
            val st = r.nextInt(buf.size - 2000)
            val fr = 1200.0 + r.nextInt(2200)
            for (i in 0 until 1200) {
                val t = i.toDouble() / RATE
                buf[st + i] += (Math.sin(2.0 * Math.PI * fr * t) * Math.exp(-t * 180.0) * 0.25).toFloat()
            }
        }
        return buf
    }

    private fun olas(): FloatArray {
        val len = RATE * 10
        val buf = FloatArray(len)
        val r = java.util.Random(11)
        var lp = 0f
        var lp2 = 0f
        for (i in 0 until len) {
            val n = r.nextFloat() * 2f - 1f
            lp += 0.06f * (n - lp)
            lp2 += 0.2f * (n - lp2)
            val s = Math.sin(Math.PI * i / (len / 2.0))
            val env = (0.1 + 0.9 * s * s).toFloat()
            buf[i] = (lp * 3f + lp2 * 0.6f * env) * env
        }
        return buf
    }
}

class SoundPlayer {
    private var track: AudioTrack? = null
    private val handler = Handler(Looper.getMainLooper())
    private var vol = 0.1f

    private val rampRunnable = object : Runnable {
        override fun run() {
            vol = minOf(1f, vol + 0.06f)
            try {
                track?.setVolume(vol)
            } catch (e: Exception) {
            }
            if (vol < 1f) handler.postDelayed(this, 1500)
        }
    }

    fun start(index: Int, rampUp: Boolean) {
        stop()
        try {
            val data = SoundSynth.generate(index)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SoundSynth.RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, data.size)
            t.setLoopPoints(0, data.size, -1)
            vol = if (rampUp) 0.1f else 0.8f
            t.setVolume(vol)
            t.play()
            track = t
            if (rampUp) handler.postDelayed(rampRunnable, 1500)
        } catch (e: Exception) {
            track = null
        }
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        val t = track
        track = null
        if (t != null) {
            try {
                t.stop()
            } catch (e: Exception) {
            }
            t.release()
        }
    }
}
