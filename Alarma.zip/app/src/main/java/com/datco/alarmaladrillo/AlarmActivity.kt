package com.datco.alarmaladrillo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.Calendar

class AlarmActivity : ComponentActivity() {

    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            finish()
        }
    }
    private var registered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!AlarmService.ringing) {
            finish()
            return
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT < 27) {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ContextCompat.registerReceiver(
            this, stopReceiver, IntentFilter(AlarmService.ACTION_STOPPED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        registered = true
        setContent {
            AlarmaTheme {
                PantallaAlarma(
                    onStop = {
                        AlarmService.stop(this)
                        finish()
                    },
                    onSnooze = {
                        AlarmService.snooze(this)
                        finish()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        if (registered) unregisterReceiver(stopReceiver)
        super.onDestroy()
    }
}

@Composable
fun PantallaAlarma(onStop: () -> Unit, onSnooze: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val cal = Calendar.getInstance()
    cal.timeInMillis = now
    val w = remember { Weather.cached(ctx) }
    val start = SleepStore.activeStart(ctx)
    val esTemporizador = AlarmService.currentType == "timer"
    val titulo = if (esTemporizador) "⌛ Temporizador" else if (AlarmService.currentLabel.isNotEmpty()) "⏰ ${AlarmService.currentLabel}" else "⏰ Alarma"

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF7A3626), Color(0xFF3F170F))))
            .systemBarsPadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(titulo, color = Color(0xFFEBCFC2), fontSize = 20.sp)
            Text(
                "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)),
                color = Color(0xFFFBF3EE), fontSize = 88.sp, fontWeight = FontWeight.Bold
            )
            Text(fechaLarga(cal), color = Color(0xFFEBCFC2), fontSize = 18.sp)
            if (w != null) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "${Weather.emoji(w.code)} ${w.city}: ${w.temp} °C, ${w.desc}",
                    color = Color(0xFFFBF3EE), fontSize = 16.sp, textAlign = TextAlign.Center
                )
            }
            if (start != 0L && !esTemporizador) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "😴 Dormiste ${fmtHM(now - start)}  ·  🔊 ${SleepStore.activeSnores(ctx).size} ronquidos",
                    color = Color(0xFFEBCFC2), fontSize = 15.sp, textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(48.dp))
            Button(
                onClick = onStop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFBF3EE), contentColor = Color(0xFF8A4535))
            ) {
                Text("Detener", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            if (!esTemporizador) {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = onSnooze,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFBF3EE)),
                    border = BorderStroke(1.5.dp, Color(0xFFEBCFC2))
                ) {
                    Text("Posponer 10 minutos", fontSize = 17.sp)
                }
            }
        }
    }
}
