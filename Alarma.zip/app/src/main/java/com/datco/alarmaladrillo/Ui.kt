@file:OptIn(ExperimentalMaterial3Api::class)

package com.datco.alarmaladrillo

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- Colores: tonos ladrillo suaves ----------
object C {
    val Bg = Color(0xFF241210)
    val Cream = Color(0xFFF3E0D6)
    val Sand = Color(0xFF3A1F1A)
    val Chip = Color(0xFF55302A)
    val Blush = Color(0xFFE2B8A8)
    val Brick = Color(0xFFA94A35)
    val BrickDark = Color(0xFFE29B84)
    val Clay = Color(0xFF8A5445)
    val Ink = Color(0xFFF3E0D6)
    val Muted = Color(0xFFC49A8B)
}

@Composable
fun AlarmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Brick,
            onPrimary = C.Cream,
            primaryContainer = C.Chip,
            onPrimaryContainer = C.Ink,
            secondary = C.Clay,
            onSecondary = C.Cream,
            background = C.Bg,
            onBackground = C.Ink,
            surface = C.Sand,
            onSurface = C.Ink,
            surfaceVariant = C.Sand,
            onSurfaceVariant = C.Muted,
            outline = C.Clay
        )
    ) {
        content()
    }
}

@Composable
fun Titulo(t: String) {
    Text(t, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = C.BrickDark, modifier = Modifier.padding(bottom = 12.dp))
}

@Composable
fun Tarjeta(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = C.Sand)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

// ---------- Splash DATCO ----------
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val escala = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(900)) }
        launch { escala.animateTo(1f, tween(900)) }
        delay(2400)
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF9C4634), Color(0xFF5E2519)))),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(alpha.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .scale(escala.value)
                    .size(110.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(C.Cream),
                contentAlignment = Alignment.Center
            ) {
                Text("D", fontSize = 64.sp, fontWeight = FontWeight.Bold, color = C.Brick)
            }
            Spacer(Modifier.height(24.dp))
            Text("DATCO", color = C.Cream, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = C.Blush, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = C.Blush, fontSize = 13.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 56.dp)
                .alpha(alpha.value)
        )
    }
}

@Composable
fun Raiz() {
    var splash by rememberSaveable { mutableStateOf(true) }
    if (splash) SplashScreen { splash = false } else PantallaPrincipal()
}

// ---------- Pantalla principal con pestañas ----------
class StopwatchState {
    var running by mutableStateOf(false)
    var acc by mutableLongStateOf(0L)
    var startedAt by mutableLongStateOf(0L)
    var now by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>()

    fun elapsed(): Long = if (running) acc + (now - startedAt) else acc

    fun toggle() {
        if (running) {
            now = SystemClock.elapsedRealtime()
            acc = elapsed()
            running = false
        } else {
            startedAt = SystemClock.elapsedRealtime()
            now = startedAt
            running = true
        }
    }

    fun lap() {
        now = SystemClock.elapsedRealtime()
        laps.add(0, elapsed())
    }

    fun reset() {
        running = false
        acc = 0L
        laps.clear()
    }
}

@Composable
fun PantallaPrincipal() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var permVersion by remember { mutableIntStateOf(0) }
    val sw = remember { StopwatchState() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permVersion += 1
    }
    LaunchedEffect(Unit) {
        val pedir = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) pedir.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(pedir.toTypedArray())
    }
    LaunchedEffect(Unit) {
        while (true) {
            tick = System.currentTimeMillis()
            delay(1000)
        }
    }
    val items = listOf("⏰" to "Alarmas", "🌙" to "Sueño", "⏱️" to "Cronómetro", "⌛" to "Temporizador")
    Scaffold(
        containerColor = C.Bg,
        bottomBar = {
            NavigationBar(containerColor = C.Sand) {
                items.forEachIndexed { i, par ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(par.first, fontSize = 20.sp) },
                        label = { Text(par.second, fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = C.Chip,
                            selectedTextColor = C.BrickDark,
                            unselectedTextColor = C.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> AlarmasTab(tick, permVersion)
                1 -> SuenoTab(tick)
                2 -> CronometroTab(sw)
                else -> TemporizadorTab(tick)
            }
        }
    }
}

// ---------- Alarmas ----------
@Composable
fun TarjetaClima(w: WeatherInfo?) {
    Tarjeta {
        if (w == null) {
            Text("Clima no disponible todavía", fontWeight = FontWeight.Bold, color = C.Ink)
            Text("Activá la ubicación y la conexión a internet para ver el clima de tu ciudad.", color = C.Muted, fontSize = 13.sp)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Weather.emoji(w.code), fontSize = 38.sp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("${w.city}: ${w.temp} °C", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Ink)
                    Text(w.desc.replaceFirstChar { it.uppercase() }, color = C.Muted)
                }
            }
        }
    }
}

@Composable
fun AlarmaItem(a: Alarm, onClick: () -> Unit, onToggle: (Boolean) -> Unit) {
    Tarjeta(Modifier.padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp)).clickable { onClick() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "%02d:%02d".format(a.hour, a.minute),
                    fontSize = 38.sp, fontWeight = FontWeight.Bold,
                    color = if (a.enabled) C.Ink else C.Muted
                )
                val extra = if (a.label.isNotEmpty()) "  ·  ${a.label}" else ""
                Text(diasTexto(a.days) + extra, color = C.Muted, fontSize = 14.sp)
                Text("🎵 ${SoundSynth.NAMES[a.sound.coerceIn(0, SoundSynth.NAMES.size - 1)]}", color = C.Muted, fontSize = 13.sp)
            }
            Switch(
                checked = a.enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = C.Cream,
                    checkedTrackColor = C.Brick,
                    uncheckedThumbColor = C.Cream,
                    uncheckedTrackColor = C.Chip,
                    uncheckedBorderColor = C.Clay
                )
            )
        }
    }
}

@Composable
fun AlarmasTab(tick: Long, permVersion: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var alarms by remember { mutableStateOf(AlarmStore.load(ctx)) }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var weather by remember { mutableStateOf(Weather.cached(ctx)) }
    val sonando = AlarmService.ringing

    LaunchedEffect(permVersion) {
        withContext(Dispatchers.IO) { Weather.fetch(ctx) }
        weather = Weather.cached(ctx)
        Weather.requestFresh(ctx) {
            scope.launch {
                withContext(Dispatchers.IO) { Weather.fetch(ctx) }
                weather = Weather.cached(ctx)
            }
        }
    }
    LaunchedEffect(tick / 5000L) {
        if (editing == null) alarms = AlarmStore.load(ctx)
    }

    fun persist(upd: Alarm) {
        try {
            val list = AlarmStore.load(ctx).map { if (it.id == upd.id) upd else it }
            AlarmStore.save(ctx, list)
            Scheduler.schedule(ctx, upd)
            alarms = list
        } catch (e: Exception) {
            Toast.makeText(ctx, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Titulo("Alarmas")
        if (sonando) {
            Button(onClick = { AlarmService.stop(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("🔔 Detener la alarma que está sonando")
            }
            Spacer(Modifier.height(12.dp))
        }
        TarjetaClima(weather)
        Spacer(Modifier.height(14.dp))
        if (alarms.isEmpty()) {
            Text("Todavía no hay alarmas. Tocá “Nueva alarma”.", color = C.Muted, modifier = Modifier.padding(vertical = 12.dp))
        }
        alarms.sortedBy { it.hour * 60 + it.minute }.forEach { a ->
            AlarmaItem(a, onClick = { editing = a }, onToggle = { on ->
                val upd = a.copy(enabled = on)
                persist(upd)
                if (on) Toast.makeText(ctx, "Sonará en ${AlarmStore.restante(upd)}", Toast.LENGTH_SHORT).show()
            })
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { editing = Alarm(0, 7, 0, emptySet(), true, 0, "") },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("＋ Nueva alarma", fontSize = 16.sp)
        }
        Spacer(Modifier.height(24.dp))
    }

    editing?.let { cur ->
        EditorAlarma(
            inicial = cur,
            onDismiss = { editing = null },
            onSave = { a ->
                try {
                    val list = AlarmStore.load(ctx).toMutableList()
                    val saved = if (a.id == 0) a.copy(id = AlarmStore.nextId(list)) else a
                    val idx = list.indexOfFirst { it.id == saved.id }
                    if (idx >= 0) list[idx] = saved else list.add(saved)
                    AlarmStore.save(ctx, list)
                    Scheduler.schedule(ctx, saved)
                    alarms = list
                    editing = null
                    Toast.makeText(ctx, "Sonará en ${AlarmStore.restante(saved)}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    editing = null
                    Toast.makeText(ctx, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            },
            onDelete = if (cur.id != 0) {
                {
                    Scheduler.cancel(ctx, cur.id)
                    val list = AlarmStore.load(ctx).filter { it.id != cur.id }
                    AlarmStore.save(ctx, list)
                    alarms = list
                    editing = null
                }
            } else null
        )
    }
}

@Composable
fun EditorAlarma(inicial: Alarm, onDismiss: () -> Unit, onSave: (Alarm) -> Unit, onDelete: (() -> Unit)?) {
    val ctx = LocalContext.current
    var hour by remember { mutableIntStateOf(inicial.hour) }
    var minute by remember { mutableIntStateOf(inicial.minute) }
    var days by remember { mutableStateOf(inicial.days) }
    var sound by remember { mutableIntStateOf(inicial.sound) }
    var label by remember { mutableStateOf(inicial.label) }
    var playing by remember { mutableIntStateOf(-1) }
    val player = remember { SoundPlayer() }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.Bg,
        title = { Text(if (inicial.id == 0) "Nueva alarma" else "Editar alarma", color = C.BrickDark) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(ctx, { _, h, m ->
                            hour = h
                            minute = m
                        }, hour, minute, true).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("%02d:%02d".format(hour, minute), fontSize = 40.sp, color = C.Ink)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DIAS_SEL.forEach { par ->
                        val num = par.first
                        val sel = days.contains(num)
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (sel) C.Brick else C.Chip)
                                .clickable { days = if (sel) days - num else days + num },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(par.second, color = if (sel) C.Cream else C.Ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    if (days.isEmpty()) "Sin días marcados: suena una sola vez" else diasTexto(days),
                    color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text("Sonido para despertar", fontWeight = FontWeight.Bold, color = C.Ink)
                SoundSynth.NAMES.forEachIndexed { i, nombre ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sound = i },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = sound == i,
                            onClick = { sound = i },
                            colors = RadioButtonDefaults.colors(selectedColor = C.Brick)
                        )
                        Text(nombre, Modifier.weight(1f), color = C.Ink)
                        TextButton(onClick = {
                            if (playing == i) {
                                player.stop()
                                playing = -1
                            } else {
                                player.start(i, false)
                                playing = i
                            }
                        }) {
                            Text(if (playing == i) "⏹ Parar" else "▶ Probar", color = C.BrickDark)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it.take(30) },
                    label = { Text("Nombre (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                player.stop()
                onSave(inicial.copy(hour = hour, minute = minute, days = days, sound = sound, label = label.trim(), enabled = true))
            }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = {
                        player.stop()
                        onDelete()
                    }) { Text("Eliminar", color = C.BrickDark) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar", color = C.Muted) }
            }
        }
    )
}

// ---------- Sueño ----------
@Composable
fun BarrasRonquidos(n: Night) {
    val horas = (((n.end - n.start) / 3_600_000L).toInt() + 1).coerceIn(1, 14)
    val cuentas = IntArray(horas)
    for (t in n.snores) {
        val i = ((t - n.start) / 3_600_000L).toInt()
        if (i in 0 until horas) cuentas[i] += 1
    }
    val mx = maxOf(1, cuentas.maxOrNull() ?: 1)
    Row(
        Modifier.fillMaxWidth().height(56.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        cuentas.forEach { c ->
            val frac = if (c == 0) 0.05f else 0.15f + 0.85f * c / mx
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight(frac)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (c == 0) C.Chip else C.Brick)
            )
        }
    }
}

@Composable
fun SuenoTab(tick: Long) {
    val ctx = LocalContext.current
    var activeStart by remember { mutableLongStateOf(SleepStore.activeStart(ctx)) }
    var snoreCount by remember { mutableIntStateOf(SleepStore.activeSnores(ctx).size) }
    var history by remember { mutableStateOf(SleepStore.history(ctx)) }
    var sens by remember { mutableIntStateOf(SleepStore.sensitivity(ctx)) }

    fun empezar() {
        try {
            SleepService.start(ctx)
            activeStart = SleepStore.activeStart(ctx)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se pudo iniciar el registro de sueño", Toast.LENGTH_LONG).show()
        }
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) empezar() else Toast.makeText(ctx, "Sin permiso de micrófono no se pueden detectar ronquidos", Toast.LENGTH_LONG).show()
    }

    LaunchedEffect(tick) {
        activeStart = SleepStore.activeStart(ctx)
        snoreCount = SleepStore.activeSnores(ctx).size
    }
    LaunchedEffect(activeStart) {
        history = SleepStore.history(ctx)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Titulo("Sueño")
        if (activeStart != 0L) {
            Tarjeta {
                Text("Durmiendo…", color = C.Muted)
                Text(fmtDur(tick - activeStart), fontSize = 44.sp, fontWeight = FontWeight.Bold, color = C.Ink)
                Spacer(Modifier.height(4.dp))
                Text("🔊 Ronquidos detectados: $snoreCount", color = C.Ink)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        SleepService.end(ctx)
                        activeStart = 0L
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Terminé de dormir") }
            }
            Text(
                "Al detener la alarma, la sesión termina sola.",
                color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            Tarjeta {
                Text(
                    "Dejá el celular cerca de la cama y enchufado. La app mide cuánto dormís y anota cuándo roncás.",
                    color = C.Ink
                )
                Spacer(Modifier.height(12.dp))
                Text("Sensibilidad del micrófono", fontWeight = FontWeight.Bold, color = C.Ink)
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Baja", "Media", "Alta").forEachIndexed { i, nombre ->
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (sens == i) C.Brick else C.Chip)
                                .clickable {
                                    sens = i
                                    SleepStore.setSensitivity(ctx, i)
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(nombre, color = if (sens == i) C.Cream else C.Ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text("Alta detecta ronquidos más suaves, pero puede confundir otros ruidos.", color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (ok) empezar() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("🌙 Empezar a dormir", fontSize = 16.sp) }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("Últimas noches", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.BrickDark)
        Spacer(Modifier.height(8.dp))
        if (history.isEmpty()) {
            Text("Todavía no hay noches registradas.", color = C.Muted)
        }
        history.take(7).forEachIndexed { i, n ->
            Tarjeta(Modifier.padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(fechaCorta(n.start), color = C.Muted, fontSize = 13.sp)
                        Text("😴 ${fmtHM(n.end - n.start)}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.Ink)
                    }
                    Text(
                        if (n.snores.isEmpty()) "Sin ronquidos" else "🔊 ${n.snores.size} ronquidos",
                        color = C.Ink
                    )
                }
                if (i == 0 && n.snores.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Ronquidos por hora", color = C.Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    BarrasRonquidos(n)
                }
            }
        }
        Text(
            "La detección es aproximada: no es un estudio médico.",
            color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )
    }
}

// ---------- Cronómetro ----------
@Composable
fun CronometroTab(sw: StopwatchState) {
    LaunchedEffect(sw.running) {
        while (sw.running) {
            sw.now = SystemClock.elapsedRealtime()
            delay(30)
        }
    }
    Column(
        Modifier.fillMaxSize().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Titulo("Cronómetro")
        Spacer(Modifier.height(16.dp))
        Text(fmtCrono(sw.elapsed()), fontSize = 52.sp, fontWeight = FontWeight.Bold, color = C.Ink)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { if (sw.running) sw.lap() else sw.reset() }) {
                Text(if (sw.running) "Vuelta" else "Reiniciar", color = C.BrickDark)
            }
            Button(onClick = { sw.toggle() }) {
                Text(if (sw.running) "Pausar" else "Iniciar")
            }
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            sw.laps.forEachIndexed { i, total ->
                val anterior = if (i + 1 < sw.laps.size) sw.laps[i + 1] else 0L
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Vuelta ${sw.laps.size - i}", color = C.Muted)
                    Text(fmtCrono(total - anterior), color = C.Ink)
                    Text(fmtCrono(total), color = C.Muted)
                }
            }
        }
    }
}

// ---------- Temporizador ----------
@Composable
fun TemporizadorTab(tick: Long) {
    val ctx = LocalContext.current
    var end by remember { mutableLongStateOf(TimerStore.end(ctx)) }
    var minTxt by remember { mutableStateOf("5") }
    var secTxt by remember { mutableStateOf("0") }
    LaunchedEffect(tick) { end = TimerStore.end(ctx) }
    val restante = end - tick

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Titulo("Temporizador")
        Spacer(Modifier.height(16.dp))
        if (end == 0L) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = minTxt,
                    onValueChange = { minTxt = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Minutos") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(120.dp)
                )
                OutlinedTextField(
                    value = secTxt,
                    onValueChange = { secTxt = it.filter { c -> c.isDigit() }.take(2) },
                    label = { Text("Segundos") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(120.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10, 15, 30).forEach { m ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(C.Chip)
                            .clickable {
                                minTxt = m.toString()
                                secTxt = "0"
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) { Text("$m min", color = C.Ink, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    val m = minTxt.toIntOrNull() ?: 0
                    val s = secTxt.toIntOrNull() ?: 0
                    val ms = (m * 60L + s) * 1000L
                    if (ms > 0) {
                        TimerStore.start(ctx, ms)
                        end = TimerStore.end(ctx)
                    } else {
                        Toast.makeText(ctx, "Poné un tiempo mayor a cero", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Iniciar", fontSize = 16.sp) }
        } else if (restante > 0) {
            val seg = (restante + 999L) / 1000L
            Text("%02d:%02d".format(seg / 60, seg % 60), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = C.Ink)
            Spacer(Modifier.height(24.dp))
            OutlinedButton(
                onClick = {
                    TimerStore.clear(ctx)
                    end = 0L
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Cancelar", color = C.BrickDark) }
        } else {
            Text("¡Tiempo!", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = C.BrickDark)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    if (AlarmService.ringing) AlarmService.stop(ctx)
                    TimerStore.clear(ctx)
                    end = 0L
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Aceptar", fontSize = 16.sp) }
        }
    }
}
