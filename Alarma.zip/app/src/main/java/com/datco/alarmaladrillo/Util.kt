package com.datco.alarmaladrillo

import java.util.Calendar

val DIAS_LARGO = arrayOf("domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado")
val MESES = arrayOf(
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"
)
val DIAS_SEL = listOf(2 to "L", 3 to "M", 4 to "X", 5 to "J", 6 to "V", 7 to "S", 1 to "D")

fun diasTexto(d: Set<Int>): String {
    if (d.isEmpty()) return "Una sola vez"
    if (d.size == 7) return "Todos los días"
    val orden = listOf(2, 3, 4, 5, 6, 7, 1)
    val nom = mapOf(2 to "Lun", 3 to "Mar", 4 to "Mié", 5 to "Jue", 6 to "Vie", 7 to "Sáb", 1 to "Dom")
    return orden.filter { d.contains(it) }.joinToString(" ") { nom[it] ?: "" }
}

fun fmtDur(ms: Long): String {
    val s = if (ms < 0) 0L else ms / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun fmtHM(ms: Long): String {
    val min = if (ms < 0) 0L else ms / 60000
    val h = min / 60
    val m = min % 60
    return if (h > 0) "$h h $m min" else "$m min"
}

fun fmtCrono(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = (ms / 60000) % 60
    val h = ms / 3600000
    return if (h > 0) "%d:%02d:%02d.%02d".format(h, m, s, cs) else "%02d:%02d.%02d".format(m, s, cs)
}

fun fechaLarga(c: Calendar): String =
    "${DIAS_LARGO[c.get(Calendar.DAY_OF_WEEK) - 1]} ${c.get(Calendar.DAY_OF_MONTH)} de ${MESES[c.get(Calendar.MONTH)]}"

fun fechaCorta(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return "${DIAS_LARGO[c.get(Calendar.DAY_OF_WEEK) - 1].take(3)} ${c.get(Calendar.DAY_OF_MONTH)} ${MESES[c.get(Calendar.MONTH)].take(3)}"
}

fun mensajeVoz(w: WeatherInfo?, type: String): String {
    if (type == "timer") return "El temporizador terminó."
    val c = Calendar.getInstance()
    val h = c.get(Calendar.HOUR_OF_DAY)
    val m = c.get(Calendar.MINUTE)
    val saludo = when {
        h < 12 -> "Buenos días"
        h < 20 -> "Buenas tardes"
        else -> "Buenas noches"
    }
    val periodo = when {
        h < 12 -> "de la mañana"
        h < 20 -> "de la tarde"
        else -> "de la noche"
    }
    val h12 = if (h % 12 == 0) 12 else h % 12
    val inicio = if (h12 == 1) "Es la una" else "Son las $h12"
    val minutos = if (m > 0) " y $m" else " en punto"
    val fecha = "Hoy es ${fechaLarga(c)}"
    val clima = if (w != null) " En ${w.city} hay ${w.temp} grados, ${w.desc}." else ""
    return "$saludo. $fecha. $inicio$minutos $periodo.$clima"
}
