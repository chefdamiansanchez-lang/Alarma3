# Alarma (DATCO)

App Android de alarma en tonos ladrillo oscuros.

- Alarmas por día, con sonidos suaves que suben de a poco (Amanecer, Pájaros, Lluvia suave, Olas, Caja de música)
- Voz al despertar: día, hora y clima de tu ciudad
- Sueño: horas dormidas y detección de ronquidos
- Cronómetro con vueltas y temporizador
- Splash de DATCO

## Compilar en GitHub
1. Subí Alarma.zip al repositorio (rama main), sin descomprimir.
2. Entrá a Actions > "Compilar Alarma" (se ejecuta solo al subir).
3. Al terminar, bajá el artefacto "Alarma-APK" y abrí app-debug.apk en el celular.
